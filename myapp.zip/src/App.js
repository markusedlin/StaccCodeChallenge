import React, {Component} from 'react'
import Info from './components/Info.js'

class App extends Component{

  constructor(){
    super();
  }
  
  render() {
    return (
      <div>
        
        {<Info/>}
      </div>
    )
  }
}
export default App