import csv

nameIndex = 2;
countryCodeIndex = 5;

with open("pep.csv", mode = 'r', errors="ignore") as f:
    csvFile = csv.reader(f)
    with open("extractedVals.txt", 'w') as wf:
        for line in csvFile:
            wf.write('"'+line[nameIndex]+'"' + ",")