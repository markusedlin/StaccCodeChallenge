import React, {useState, useEffect} from 'react'
import Axios from 'axios'
import './info.css'

export default function Info() {
    const [name, setName] = useState("")
    const [score, setScore] = useState("")
    const [alias, setAlias] = useState("")
    const [aliases, setAliases] = useState("")
    const [birth_date, setBirth_date] = useState("")
    const [age, setAge] = useState("")
    const [country, setCountry] = useState("")
    const [dataset, setDataset] = useState("")
    const [emails, setEmails] = useState("")
    const [id, setId] = useState("")
    const [firstSeen, setFirstSeen] = useState("")
    const [lastSeen, setLastSeen] = useState("")
    const [phones, setPhones] = useState("")
    const [sanctions, setSanctions] = useState("")
    const [identifier, setIdentifier] = useState("")
    const [schema, setSchema] = useState("")
    
    const [input, setInput] = useState("")
    const [loading, setLoading] = useState(false)
    const [loadingText, setLoadingText] = useState("")
    // const [isVisible, setVisible] = useState(false)

    // document.querySelector("input").addEventListener("keypress", (e) =>{
    //     if(e.key === "Enter"){
    //         console.log("enter pressed")
    //     }
    // })

    function handleClick(){
        if(!loading){
            setLoading(true)
        }
        const inputElem = document.querySelector("input")
        const input = inputElem.value
        /* If trimmed input is empty, then end the search */
        if(input.trim() == ""){
            inputElem.value = ""
            return;
        }

        setInput(input)

        const getData = async () =>{
            const response = await Axios.get(`https://code-challenge.stacc.dev/api/pep?name=${input}`)
            .catch(error => console.error("something went wrong with request:", error))
            const data = response.data["hits"][0]
            const name = data["name"]
            const score = data["score"]
            let aliasesResponse = data["aliases"].split(";")
            const birth_date = data["birth_date"]
            const country = data["countries"]
            const emails = data["emails"]
            const dataset = data["dataset"]
            const firstSeen = data["first_seen"]
            const lastSeen = data["last_seen"]
            const id = data["id"]
            const phones = data["phones"]
            const sanctions = data["sanctions"]
            const schema = data["schema"]
            const identifier = data["identifier"]

            console.log(data) // log all of object
            
            setName("Name: "+name)
            setScore("Score: "+score)
            setCountry("Country: "+country)
            setEmails("Emails: "+emails)
            setDataset("Dataset: "+dataset)
            setFirstSeen("First Seen: "+firstSeen)
            setLastSeen("Last Seen: "+lastSeen)
            setId("ID: "+id)
            setPhones("Phones: "+phones)
            setSanctions("Sanctions: "+sanctions)
            setSchema("Schema: "+schema)
            setIdentifier("Identifier: "+identifier)

            setBirth_date("Birthdate: "+birth_date)
            const today = new Date()
            setAge("Age: "+getAge(today,new Date(birth_date)))

            setLoadingText("")
            
            if(aliasesResponse.length > 1){
                setAliases("Aliases: "+response.data["hits"][0]["aliases"])
            }else{
                setAlias("Alias: "+aliasesResponse[0])
            }
            // try{
                
            //     const tableElem = document.querySelector("tableDiv")
            //     tableElem.style.display = "none";
            //     //.style.visibility = "visible";
            //     console.log("tableDiv accessible")
            // }
            // catch{
            //     console.log("tableDiv not accessible")
            // }

        }
        getData()
    }
    /* Reset states to empty*/
    function resetStates(){ 
        setName("")
        setAge("")
        setAlias("")
        setAliases([])
        setScore("")
        setCountry("")
        setEmails("")
        setDataset("")
        setFirstSeen("")
        setLastSeen("")
        setId("")
        setPhones("")
        setSanctions("")
        setSchema("")
        setIdentifier("")
    }

    //this should only happen when the input is changed after clicking the button
    useEffect(() => {
        if(loading){
            resetStates()
            //do some sort of loading animation
            setLoadingText("Searching...")
        }
    }, [input]);

    /* Calculates the age based on today's date 
    param1 d1:
    */
    function getAge(d1, d2){
        let age = 0
        const d1Year = d1.getYear()
        const d1Month = d1.getMonth()
        const d1Day = d1.getDate()

        const d2Year = d2.getYear()
        const d2Month = d2.getMonth()
        const d2Day = d2.getDate()

        age = Math.abs(d1Year-d2Year)
        if((d1Month === d2Month) && (d1Day < d2Day)){
            age -= 1
        }else if(d1Month<d2Month){
            age -= 1
        }
        return age
    }

    return (
    <div id="app">
        <div id="logoContainer">
            <p class="logo" id="P">P</p>
            <p class="logo" id="E">E</p>
            <p class="logo" id="P2">P</p>
        </div>
        <div id="inputAndButton">
            <input autoFocus={true} class="input" type="text" placeholder="Who are you looking for?"></input>
            <button class="button" onClick={handleClick}>Search</button>      
        </div>
        <div id="tableDiv">
            {/* <table>
                <tbody>
                    <tr>
                        <th>Name</th>
                        <td><div class="info" id="name">{name}</div></td>
                    </tr>
                    <tr>
                        <th>Score</th>
                        <td><div class="info" id="score">{score}</div></td>
                    </tr>
                    <tr>
                        <th>Age</th>
                        <td><div class="info" id="birthdate">{age}</div></td>
                    </tr>
                    <tr>
                        <th>Aliases</th>
                        <td><div class="info" id="aliases">{aliases}</div></td>
                    </tr>
                    <tr>
                        <th>alias</th>
                        <td><div class="info" id="alias">{alias}</div></td>
                    </tr>
                </tbody>
            </table> */}
        </div>
        <div id="loading">
            {loadingText}
        </div>
        <div id="infoDiv">
            <div class="info" id="name">{name}</div>
            <div class="info" id="score">{score}</div>
            <div class="info" id="birthdate">{age} </div>
            <div class="info" id="countries">{country}</div>
            <div id="alias">{alias}</div>
            <div class="info" id="aliases"><p>{aliases}</p></div>
            <div class="info" id="first_seen">{firstSeen}</div>
            <div class="info" id="last_seen">{lastSeen}</div>
            <div class="info" id="id">{id}</div>
            <div class="info" id="identifier">{identifier}</div>
            <div class="info" id="phones">{phones}</div>
            <div class="info" id="emails">{emails}</div>
            <div class="info" id="sanctions">{sanctions}</div>
            <div class="info" id="schema">{schema}</div>
            <div class="info" id="dataset">{dataset}</div>

            {/* <div id="birthdate">{birth_date} </div> */}
        </div>
    </div>) 
}